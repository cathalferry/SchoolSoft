﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Admin_Create_Edit_Courses.xaml
    /// </summary>
    public partial class Admin_Create_Edit_Courses : Window
    {
        SS_Entities dbEntitiesCourses = new SS_Entities();
        public Login_Table user = new Login_Table();
        List<Student_Table> studentlist = new List<Student_Table>();
        List<Course_Table> courseList = new List<Course_Table>();
        Course_Table currentCourse = new Course_Table();
        string entityState = "Add";
        public Admin_Create_Edit_Courses()


        {
            try {
                InitializeComponent();
                mtdLoadCourses();
                listView.ItemsSource = courseList;
                btnEdit.Visibility = Visibility.Collapsed;
            }
            catch (Exception)
            {
                MessageBox.Show("Error Loading Courses from Database");
            }
        }

        private void mtdLoadCourses()
        {
            courseList.Clear();
            foreach (var user in dbEntitiesCourses.Course_Table)
            {
                courseList.Add(user);

                //   textBox1.Text = user.Course_ID;

            }
            Course_Table newtable = new Course_Table();
            //dataGrid.ItemsSource = courseList.DefaultIfEmpty();
            //  listBox.ItemsSource = courseList.DefaultIfEmpty();

        }


        private void textBox_Add(object sender, System.EventArgs e)
        {

        }


        private void tbxStudentID_Copy2_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {




            this.Hide();

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            entityState = "Edit";
            tbxClass1.IsReadOnly = false;
            tbxClass2.IsReadOnly = false;
            tbxClass3.IsReadOnly = false;
            tbxCourseID.IsReadOnly = false;
            tbxCourseTitle.IsReadOnly = false;


            currentCourse.Class_Detail = tbxClass1.Text.Trim();
            currentCourse.Class_Detail2 = tbxClass2.Text.Trim();
            currentCourse.Class_Detail3 = tbxClass3.Text.Trim();
            currentCourse.Course_ID = tbxCourseID.Text.Trim();
            currentCourse.Course_Title = tbxCourseTitle.Text.Trim();


            bool courseVerified = mtdVerifyCourse(currentCourse);
            if (courseVerified)
            {
                mtdAddCourse(currentCourse, entityState);//add the appended course details to the DB

                listView.Items.Refresh(); //refresh the DB

            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (entityState == "Cancel Edit") //check if user selected cancel edit
            {
                mtdClearUserDetails();  //clear textboxes
                entityState = "Add";  //revert to add record mode
                btnEdit.Visibility = Visibility.Collapsed;  //hide the edit button
                btnAdd.Content = "Apply";  //change te

            }
         else  if (entityState == "Add")
            { 
            currentCourse.Class_Detail = tbxClass1.Text.Trim();
            currentCourse.Class_Detail2 = tbxClass2.Text.Trim();
            currentCourse.Class_Detail3 = tbxClass2.Text.Trim();
            currentCourse.Course_ID = tbxCourseID.Text.Trim();
            currentCourse.Course_Title = tbxCourseTitle.Text.Trim();
            bool courseVerified = mtdVerifyCourse(currentCourse);
            if (courseVerified)
           {
                mtdAddCourse(currentCourse, entityState);

                listView.Items.Refresh();
                //  mtdPopulateCourseDetails();
            }

        }
    }
        private void mtdClearUserDetails()
        {
            tbxCourseTitle.Text = "";
            tbxCourseID.Text = "";
            tbxClass1.Text = "";
            tbxClass2.Text = "";
            tbxClass3.Text = "";


        }
        private void mtdAddCourse(Course_Table course, string modifyState)
        {
            try
            {
                

                    if (entityState == "Edit")//edit button pressed to update record
                    {
                        foreach (var courseRecord in dbEntitiesCourses.Course_Table.Where(t => t.Course_ID == course.Course_ID))
                        {
                            courseRecord.Course_ID = course.Course_ID;
                            courseRecord.Course_Title = course.Course_Title;
                            courseRecord.Class_Detail = course.Class_Detail;
                            courseRecord.Class_Detail2 = course.Class_Detail2;
                            courseRecord.Class_Detail3 = course.Class_Detail3;
               

                            MessageBox.Show("Course Modified");
                        }
                    }
                  else  if (entityState == "Add") 
                    {
                    //add a new record to the database
                        course.Course_ID = tbxCourseID.Text.Trim();
                        course.Class_Detail2 = tbxClass2.Text.Trim();
                        course.Class_Detail3 = tbxClass3.Text.Trim();
                        course.Class_Detail = tbxClass1.Text.Trim();
                        course.Course_Title = tbxCourseTitle.Text.Trim();
                    
                   
                        dbEntitiesCourses.Configuration.AutoDetectChangesEnabled = false;
                        dbEntitiesCourses.Configuration.ValidateOnSaveEnabled = false;
                        dbEntitiesCourses.Entry(course).State = System.Data.Entity.EntityState.Added;
                        MessageBox.Show("New course added");
                   
                    }
                    dbEntitiesCourses.SaveChanges();
                    dbEntitiesCourses.Configuration.AutoDetectChangesEnabled = true;
                    dbEntitiesCourses.Configuration.ValidateOnSaveEnabled = true;
                    mtdClearUserDetails(); //clear texboxes after
                
             
            }
            catch (Exception)
            {
                MessageBox.Show("Problem writing to database!");
            }
            
       }
        private bool mtdVerifyCourse(Course_Table courses)
        {
            bool courseVerified = false;
            try
            {
                if (courses.Course_ID == null)
                {
                    courses.Course_ID = "";
                }
                if (courses.Class_Detail == null)
                {
                    courses.Class_Detail = "";
                }
                if (courses.Class_Detail2 == null)
                {
                    courses.Class_Detail2 = "";
                }
                if (courses.Course_Title == null)
                {
                    courses.Course_Title = "";
                }
                if (courses.Class_Detail3 == null)
                {
                    courses.Class_Detail3 = "";
                }
                courseVerified = true;
            
            }
        
            catch (Exception)
            {
                MessageBox.Show("Error verifying course details!");
                
            }
            return courseVerified;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        
            
            mtdLoadCourses();
            listView.ItemsSource = courseList;
        }



        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void tbxClass3_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        }
        private void dataGrid_RowClick(object sender, DataGridRow  e)
        {
            
        }
 

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(courseList.Count>0)
            {
                currentCourse = courseList.ElementAt(this.listView.SelectedIndex);
                mtdPopulateCourseDetails(currentCourse);
            }
            btnEdit.Visibility = Visibility.Visible;
         //   btnAdd.Visibility = Visibility.Hidden;
            btnAdd.Content = "Cancel Edit";
            entityState = "Cancel Edit";
            //entityState = "Cancel";
        }

        private void mtdPopulateCourseDetails(Course_Table selectedCourses)
        {
            try {
                tbxClass1.Text = selectedCourses.Class_Detail;
                tbxClass2.Text = selectedCourses.Class_Detail2;
                tbxClass3.Text = selectedCourses.Class_Detail3;
                tbxCourseID.Text = selectedCourses.Course_ID;
                tbxCourseTitle.Text = selectedCourses.Course_Title;
            }
            catch(Exception)
            {
                MessageBox.Show("Problem with Course Selection!");
          
            }
        }

     
    }

    }

