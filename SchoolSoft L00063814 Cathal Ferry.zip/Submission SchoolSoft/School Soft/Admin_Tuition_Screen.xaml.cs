﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Admin_Tuition_Screen.xaml
    /// </summary>
    public partial class Admin_Tuition_Screen : Window
    {
        public Student_Table student = new Student_Table();
        Student_Table currentStudent = new Student_Table();
        SS_Entities dbEntities = new SS_Entities();
        public Admin_Tuition_Screen()
        {
            InitializeComponent();
    
        }



        private void btnfees_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (student.Fee_Status == 1 )  //check if fees are not paid i.e. status=1
                {
                    foreach (var feeRecord in dbEntities.Student_Table.Where(t => t.UserID == student.UserID))
                    {
                        //update the fees status and leave otehr entries in record default
                        feeRecord.UserID = student.UserID;
                        feeRecord.Surname = student.Surname;
                        feeRecord.Forename = student.Forename;
                        feeRecord.Fee_Status = 2;
                        feeRecord.Contact = student.Contact;
                        feeRecord.Address2 = student.Address2;
                        feeRecord.Address1 = student.Address1;
                        feeRecord.Course_ID = student.Course_ID;
                        // MessageBox.Show("Fee status updated!");
                

                    }
                }
                else if (student.Fee_Status == 2) //check if fees are paid
                {  //update the fees status and leave otehr entries in record default
                    foreach (var feeRecord in dbEntities.Student_Table.Where(t => t.UserID == student.UserID))
                    {
                        feeRecord.UserID = student.UserID;
                        feeRecord.Surname = student.Surname;
                        feeRecord.Forename = student.Forename;
                        feeRecord.Fee_Status = 1;
                        feeRecord.Contact = student.Contact;
                        feeRecord.Address2 = student.Address2;
                        feeRecord.Address1 = student.Address1;
                        feeRecord.Course_ID = student.Course_ID;
                    

                    }
                }
                MessageBox.Show("Fee status updated!");
                dbEntities.SaveChanges();
                dbEntities.Configuration.AutoDetectChangesEnabled = true;
                dbEntities.Configuration.ValidateOnSaveEnabled = true;
                
            }
      catch {
                MessageBox.Show("An unknown error occured");
            }
        }
      


        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
        private void mtdFeeToText()
        {
           
            if (student.Fee_Status == 2)
            {
                tbxFees.Text = "Fees are Paid";
                tbxFees.Background = Brushes.LightGreen;
                
            }
            else if (student.Fee_Status == 1)
            {
                tbxFees.Text = "Fees are not Paid";
                tbxFees.Background = Brushes.Red;
            }
            else tbxFees.Text = "Unknown Error!";
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // tbxFees.Text = student.Fee_Status.ToString();
            mtdFeeToText();
            tbxStudentID.Text = student.UserID;
            tbxForename.Text = student.Forename;
            tbxCourse.Text = student.Course_ID;
            tbxSurname.Text = student.Surname;
        }

    }
}
