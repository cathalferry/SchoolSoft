﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Admin_Search_Records.xaml
    /// </summary>
    public partial class Admin_Search_Records : Window
    {
       
        SS_Entities dbEntitiesCourses = new SS_Entities();
        public Login_Table user = new Login_Table();
        public int updater;
        List<Student_Table> studentlist = new List<Student_Table>();
        List<Course_Table> courseList = new List<Course_Table>();
        Student_Table currentRecord = new Student_Table();
       
        public Admin_Search_Records()
        {
       try {
                InitializeComponent();
                
            }
            catch
            {
                MessageBox.Show("Error initilising the application!");
            }
     
        }
        //load all student records into list view
        private void mtdLoadStudents()
        { 
            
            studentlist.Clear();
            foreach (var user in dbEntitiesCourses.Student_Table)
            {
                studentlist.Add(user);
            }
        
          }
        //load course info
        private void mtdLoadCourses()
        {
            courseList.Clear();
            foreach (var user in dbEntitiesCourses.Course_Table)
            {
                courseList.Add(user);
            }

           }


        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (listViewSearch.SelectedIndex > -1) //check that a record was selected
                {
                    Admin_Edit_Student_Record Edit_Student = new Admin_Edit_Student_Record();
                    Edit_Student.student = currentRecord; //Pass selected record info to edit student account page
                    Edit_Student.ShowDialog(); //open edit student page
                }
                else
                {
                    MessageBox.Show("Please select a record to Edit");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error loading edit student window!");
            }
        }
        //Function to open fees editing window
        private void btnFeesClick(object sender, RoutedEventArgs e)
        {
            try {
                if (listViewSearch.SelectedIndex > -1)  //check that a record is selected first
                {
                    Admin_Tuition_Screen fees = new Admin_Tuition_Screen();
                    fees.student = currentRecord; //pass current user details to tution screen
                    fees.ShowDialog();//open fees sctatus screen
                }
                else
                {   //display error if no record is selected
                    MessageBox.Show("Please select a record first");
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Error loading tuition window!");
            }
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Hide(); //hide search screen and return to admin dashboard
        }

        //function to delete a record
        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            Student_Table deleteRecord = new Student_Table();
            try
            {
                if (listViewSearch.SelectedIndex > -1) //check that a record is selected
                {
                    //confirm delte first
                    MessageBoxResult result = MessageBox.Show("Are you sure you want to delete the selected record!", "Information", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        //  dbEntitiesCourses.Student_Table.RemoveRange(dbEntitiesCourses.Student_Table.Where(t => t.UserID == deleteRecord.UserID));
                        dbEntitiesCourses.Student_Table.RemoveRange(dbEntitiesCourses.Student_Table.Where(t => t.UserID == currentRecord.UserID));
                        MessageBox.Show("User Deleted!");
                        dbEntitiesCourses.SaveChanges();
                        dbEntitiesCourses.Configuration.AutoDetectChangesEnabled = false;
                        dbEntitiesCourses.Configuration.ValidateOnSaveEnabled = false;

                    }

                    else
                    {
                        MessageBox.Show("Delete cancelled");
                    }
                    //Update DB after record is deleted
                    dbEntitiesCourses.SaveChanges();   
                    dbEntitiesCourses.Configuration.AutoDetectChangesEnabled = true;
                    dbEntitiesCourses.Configuration.ValidateOnSaveEnabled = true;
                    listViewSearch.Items.Refresh();
                }
                else
                {   //Show error if a record isnt selected to delete
                    MessageBox.Show("Please select a record to delete");
                }
            }
            catch (Exception)
            {  //error if there is a problem deleting from the DB
                MessageBox.Show("Error deleting from database");
            }
        }


        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            Student_Table userDetails = new Student_Table(); //new instance of student table for searching
            
            string searchUser = tbxSearch.Text.Trim();//removing spaces with trim  get user detials
            //cant search for admin or search empty query
            if (String.IsNullOrEmpty(tbxSearch.Text.Trim()) || (tbxSearch.Text =="Admin"))
            {

                MessageBox.Show("Error Invalid Search Term!", "Search Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
             
             listViewSearch.DataContext = null;
                mtdSearchUser(searchUser);//check if details exist in DB using method
            }
        }

        public Student_Table mtdSearchUser(string searchUser) //Method checks if entered details are in SQL DB
        {
           int SearchOk = 0; //variable to allow list to fill when valid search found
          List<Student_Table> SearchDetails = new List<Student_Table>();
            foreach (var user in studentlist )
            {
           //search by user id, course id, forename or surname
          if(searchUser==user.UserID || searchUser==user.Course_ID ||searchUser==user.Forename || searchUser==user.Surname)
                {
        
                    SearchDetails.Add (user);
                    SearchOk = 1; //real record found
                }

            }

       if (SearchOk == 1)//if real record found
         {
            listViewSearch.ItemsSource = SearchDetails;
               // listViewSearch.ItemsSource = studentlist; //display valid record info in listview
        }
         else //no valid record found for search term
         {
              MessageBox.Show("No Record Found!", "Search Results",
                 MessageBoxButton.OK, MessageBoxImage.Information);
         }

            return null; //return nothing

        }

       
    
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try {
                mtdLoadCourses();  //load all course info
                mtdLoadStudents(); //load all student info
              listViewSearch.ItemsSource = studentlist; //show student info in listview
            }
           catch (Exception)
           { //show error if info cant be read from DB
               MessageBox.Show("Error Loading DB!");
                
           }
        }
        //checkif a record was selected, used for edit student, edit fees and deleting records
        private void listViewSearch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (studentlist.Count > 0)
            {
                if (listViewSearch.SelectedIndex > -1)
                {
                    currentRecord = studentlist.ElementAt(this.listViewSearch.SelectedIndex); //currentRecord equals the selected record from the list
                   
                }
                
            }
          
        }

        private void tbxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

      

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            listViewSearch.Items.Refresh();
            listViewSearch.ItemsSource = studentlist;  //show all record entries
        }

       
    }
}
