﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Admin_Edit_Student_Record.xaml
    /// </summary>
    public partial class Admin_Edit_Student_Record : Window
    {
        

        SS_Entities dbEntities = new SS_Entities();
        public Student_Table student = new Student_Table();  //selected record from search screen
       
        List<Course_Table> courseList = new List<Course_Table>();
       // List<Course_Table> curentCourse = new List<Course_Table>();
        List<Login_Table> currentUser = new List<Login_Table>();
        Student_Table updateStudent = new Student_Table();
        Login_Table updateLogin = new Login_Table();

        public Admin_Edit_Student_Record()
        {
            InitializeComponent();
          //  mtdFillUserDetail();

        }
        //Load details of selected student record into textboxes
        private void mtdFillUserDetail()
        {
            tbxAddress1.Text = student.Address1;
            tbxAddress2.Text = student.Address2;
            tbxCourseID.Text = student.Course_ID;
            tbxForename.Text = student.Forename;
            tbxSurname.Text = student.Surname;
            tbxContact.Text = student.Contact.ToString();
            //tbxStudentID.Text = student.UserID;
           
        }
     
        public void  mtdLoadCurrentUser() //load user login details of selected record to be edited
        {
         
            //Loads user Information for the record being edited for use with changing password and login info
            foreach (var user in dbEntities.Login_Table)
            {
                if(student.UserID==user.UserID)  ///search the DB for the selected records details
                {
                    currentUser.Add(user);
                    tbxPassword.Text = user.Password;
                    tbxStudentID.Text = user.UserID;
                }
            
                
                
            }
      

        }

        private void btnback(object sender, RoutedEventArgs e)
        {
        
            this.Hide();//hide edit window on back button press
        }

        private void btnAppend_Click(object sender, RoutedEventArgs e)
        {
          try {
                //take values in textboxes and update the record
                updateStudent.UserID = tbxStudentID.Text.Trim();
                updateStudent.Address1 = tbxAddress1.Text.Trim();
                updateStudent.Address2 = tbxAddress2.Text.Trim();
                updateStudent.Contact = Convert.ToInt32(tbxContact.Text);
                updateStudent.Course_ID = tbxCourseID.Text.Trim();
            //   updateStudent.Fee_Status = student.Fee_Status;
                 updateStudent.Fee_Status = 1;
                updateStudent.Surname = tbxSurname.Text.Trim();
                updateStudent.Forename = tbxForename.Text.Trim();
                updateLogin.Admin_Status = 1;  //student by default
                updateLogin.Password = tbxPassword.Text.Trim();
                updateLogin.UserID = tbxStudentID.Text.Trim();
                //pass values to update record function
                mtdUpdateStudentRecord(updateStudent,updateLogin);
                

           }
              catch(Exception)
              {
                 MessageBox.Show("Error! Please ensure your details are correct!");
            }
 


        }
        //Update the selected record
        private void mtdUpdateStudentRecord(Student_Table students, Login_Table logins)
        {   //update student record
            foreach (var studentRecord in dbEntities.Student_Table.Where(c=>c.UserID == students.UserID))
            {
                studentRecord.UserID = students.UserID;
                studentRecord.Surname = students.Surname;
              
                studentRecord.Forename = students.Forename;
                studentRecord.Contact = students.Contact;
                studentRecord.Address2 = students.Address2;
                studentRecord.Address1 = students.Address1;
                studentRecord.Course_ID = students.Course_ID;
                studentRecord.Fee_Status = students.Fee_Status;
       
         
            }
       

            //update the login tables password, user id and default admin status
            foreach (var loginRecord in dbEntities.Login_Table.Where(t=>t.UserID==logins.UserID))
          {
            loginRecord.UserID = logins.UserID;
            loginRecord.Password = logins.Password;
              loginRecord.Admin_Status = logins.Admin_Status;
          }
         //save changes to database
            dbEntities.SaveChanges();
            dbEntities.Configuration.AutoDetectChangesEnabled = true;
            dbEntities.Configuration.ValidateOnSaveEnabled = true;
        //    mtdClearUserDetails(); //clear texboxes after
            MessageBox.Show("Student Record Updated!");
            
        }
        //emthod to clear textboxes when finishes
        private void mtdClearUserDetails()
        {
           
            tbxStudentID.Text = "";
            tbxPassword.Text = "";
            tbxSurname.Text = "";
            tbxCourseID.Text = "";
            tbxContact.Text = "";
            tbxAddress2.Text = "";
            tbxAddress1.Text = "";
            tbxForename.Text = "";



        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            mtdLoadCurrentUser(); //load textboxes with user details from login table
            mtdFillUserDetail();  //load textboxes with data from student table
            
        }
    }
}
