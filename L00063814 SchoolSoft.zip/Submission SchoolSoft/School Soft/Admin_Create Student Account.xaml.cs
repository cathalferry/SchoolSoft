﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Admin_Create_Student_Account.xaml
    /// </summary>
    public partial class Admin_Create_Student_Account : Window
    {
        SS_Entities StudentEntities = new SS_Entities();
        List<Student_Table> studentList = new List<Student_Table>();
        List<Login_Table> loginList = new List<Login_Table>();
        Student_Table students = new Student_Table();
        Login_Table login = new Login_Table();
        Course_Table course = new Course_Table();
        List<Course_Table> courseList = new List<Course_Table>();
        public Admin_Create_Student_Account()
        {
            try {
                InitializeComponent();     
                mtdPopulateStudentTable();  //Method to preload all entries in student table
                mtdPopulateLoginTable(); //Method to preload all entries in login table
               
            }
            catch (Exception)
            { //Report Error if DBs cant connect, will also display if program wont initialize
                MessageBox.Show("Error Loading Data From Database!");
            }
        }
        private void mtdPopulateStudentTable()
        { //Load up all student records
            studentList.Clear();
            foreach (var student in StudentEntities.Student_Table)
           {
                studentList.Add(student);

            }
        }
       //Load all details from login table
        private void mtdPopulateLoginTable()
        {  
            loginList.Clear();
            foreach (var user in StudentEntities.Login_Table)
            {
                loginList.Add(user);
            }
        }
         
 
        //op
        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
        
         
            try {
                //Add user defines entries in textboxes to lists for entry into database
                students.Address1 = tbxAddress1.Text.Trim();
                students.Address2 = tbxAddress2.Text.Trim();
               students.Contact = Convert.ToInt32(tbxContact.Text);
           
                students.Surname = tbxSurname.Text.Trim();
                students.Forename = tbxForename.Text.Trim();
                students.UserID = tbxStudentID.Text.Trim();
                students.Course_ID = tbxCourseID.Text.Trim();
                students.Fee_Status = 1;  //default fees unpaid
                login.UserID = tbxStudentID.Text.Trim();
                login.Password = tbxPassword.Text.Trim();
                login.Admin_Status = 1; //default student account not admin account
            }
            catch (Exception)
            { 

            MessageBox.Show("Please check student details!");
        }
            try {
                //Try and write new entry to database for login and student
                StudentEntities.Configuration.AutoDetectChangesEnabled = false;
                StudentEntities.Configuration.ValidateOnSaveEnabled = false;
                StudentEntities.Entry(students).State = System.Data.Entity.EntityState.Added;//Add users details and course ID
                StudentEntities.Entry(login).State = System.Data.Entity.EntityState.Added; //used ID, password and admin status default as student 
                
                StudentEntities.SaveChanges();
                StudentEntities.Configuration.AutoDetectChangesEnabled = true;
                StudentEntities.Configuration.ValidateOnSaveEnabled = true;
                MessageBox.Show("New user entry added!!");
                mtdClearUserDetails();
            }
            catch(Exception)
            {
                MessageBox.Show("Cannot add new student, make sure the Student_ID is unique and that the course ID exists!");
            }
  
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();//hide screen and return to dashboard
        }

        private void tbxCourseID_TextChanged(object sender, TextChangedEventArgs e)
        {
  
        }
        //Method to clear textboxes after new account is created.
        private void mtdClearUserDetails()
        {
            tbxAddress1.Text = "";
            tbxAddress2.Text = "";
            tbxContact.Text = "";
            tbxCourseID.Text = "";
            tbxForename.Text = "";
            tbxPassword.Text = "";
            tbxStudentID.Text = "";
            tbxSurname.Text = "";
    
        }



    }
}
