﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace School_Soft
{
    /// <summary>
    /// Interaction logic for Student_Tuition.xaml
    /// </summary>
    public partial class Student_Tuition : Window
    {
       
        public Login_Table user = new Login_Table();
        public Student_Table student = new Student_Table();
        SS_Entities dbEntitiesFess = new SS_Entities();
        List<Student_Table> studentlistfees = new List<Student_Table>();
  
        public Student_Tuition()
        {
            InitializeComponent();
            
        }
        
        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
          


            this.Hide();
       
        }
     
        private void mthLoadUsersFees()  //load student list
        {
            studentlistfees.Clear();
            foreach (var user in dbEntitiesFess.Student_Table)
            {
                studentlistfees.Add(user);
            }
        }

       private Student_Table mtdGetFees() 
        { //find info for logged in student
            Student_Table tuition_search = new Student_Table();
            foreach (var users in studentlistfees)
            {
                if (user.UserID==users.UserID)
                {
                   tuition_search = users;
                    
                }
               
            }
            //convert fees integer to meaningful text
            if(tuition_search.Fee_Status==1) //fees unpaid
            { 
                tbxFees.Text = " Fees unpaid";
                tbxFees.Background = Brushes.Red;
            }
            else if (tuition_search.Fee_Status==2) //2 = fees paid
            {
                tbxFees.Text = "Fees Paid!";
                tbxFees.Background = Brushes.LightGreen;
            }
            tbxCourseName.Text = tuition_search.Course_ID; 
            return null;
          //  return tuition_search;
        }

        private void tbxFees_TextChanged(object sender, TextChangedEventArgs e)
        {
         //   tbxFees.Text = login.UserID;


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        { //preload list and course and fees status
            mthLoadUsersFees(); 
          
            mtdGetFees();
            lbltext.Content = user.UserID;
        }
    }
}
